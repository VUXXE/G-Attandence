// Universal Compatibility Layer
const _runtime = (typeof browser !== 'undefined' ? browser : chrome);

console.log('%c[GMeet Attendance] ACTIVATED', 'color: #1a73e8; font-weight: bold;');

const G = {
  selectors: {
    row: '[role="listitem"], [jsname="KV1GEc"], .kv6nbe',
    name: '[jsname="V67Sbc"], [data-self-name], .zW9vS',
    peopleBtn: 'button[aria-label^="Show everyone"], button[aria-label^="Tampilkan semua"], button[jsname="H2Y76b"]',
    sidePanel: '[role="complementary"], .dqy09c'
  }
};

function getMeetingId() {
  const match = window.location.pathname.match(/\/([a-z0-9\-]+)$/);
  if (match && !['landing', 'new'].includes(match[1])) return match[1];
  return null;
}

function scrape() {
  const meetingId = getMeetingId();
  if (!meetingId) return;

  const rows = document.querySelectorAll(G.selectors.row);
  const participants = [];

  rows.forEach(row => {
    let nameEl = row.querySelector(G.selectors.name);
    let name = '';

    if (nameEl) {
      name = (nameEl.innerText || nameEl.getAttribute('data-self-name') || '').trim();
    } 
    
    if (!name || name.length < 2) {
      const textEls = Array.from(row.querySelectorAll('span, div'))
        .filter(el => el.innerText && el.innerText.trim().length > 1 && el.children.length === 0);
      if (textEls.length > 0) name = textEls[0].innerText.trim();
    }

    if (!name || name.length < 2 || name.includes(':')) return;

    // Filter out Google Meet UI noise (Indonesian and English)
    const noise = [
      'bergabung', 'joined', 'invited', 'diundang', 'memuat', 'loading', 
      'tamu', 'guest', 'orang juga', 'people also', 'undangan', 'undangan dikirim',
      'host', 'penyelenggara', 'presenting', 'mempresentasikan'
    ];
    const nameLower = name.toLowerCase();
    if (noise.some(word => nameLower.includes(word))) return;

    // Real participants usually have an avatar or a recognizable profile picture container
    const imgEl = row.querySelector('img');
    if (!imgEl && !nameLower.includes('anda') && !nameLower.includes('you')) return; 

    const youStr = (_runtime.i18n.getMessage('you') || 'You').toLowerCase();
    if (nameLower === 'you' || nameLower === 'anda' || nameLower.includes(`(${youStr})`)) {
      const selfName = document.querySelector('[data-self-name]')?.getAttribute('data-self-name');
      if (selfName) name = selfName;
    }

    participants.push({ name, avatar: imgEl ? imgEl.src : null });
  });

  const unique = Array.from(new Set(participants.map(p => p.name)))
    .map(name => participants.find(p => p.name === name));

  if (unique.length > 0) {
    console.log(`[GMeet Attendance] SYNCING: ${unique.length} participants.`);
    _runtime.runtime.sendMessage({ type: 'PARTICIPANT_UPDATE', meetingId, participants: unique }).catch(() => {});
  }
}

function createUI() {
  if (document.getElementById('gmeet-att-wrap')) return;

  const wrap = document.createElement('div');
  wrap.id = 'gmeet-att-wrap';
  wrap.style.cssText = 'position:fixed; bottom:85px; right:20px; z-index:9999; display:flex; flex-direction:column; align-items:flex-end; gap:8px;';

  const btn = document.createElement('button');
  const recordText = _runtime.i18n.getMessage('recordAttendance') || 'Record Attendance';
  btn.innerHTML = `<span>📊</span> ${recordText}`;
  btn.style.cssText = `
    padding: 15px 25px;
    background: #FFDE59;
    color: #000;
    border: 4px solid #000;
    font-weight: 900;
    text-transform: uppercase;
    cursor: pointer;
    box-shadow: 6px 6px 0px #000;
    font-size: 14px;
    font-family: 'Courier New', monospace;
    transition: all 0.1s;
  `;

  btn.onmousedown = () => {
    btn.style.transform = 'translate(4px, 4px)';
    btn.style.boxShadow = '0px 0px 0px #000';
  };

  btn.onmouseup = () => {
    btn.style.transform = 'translate(0px, 0px)';
    btn.style.boxShadow = '6px 6px 0px #000';
  };

  btn.onclick = async () => {
    btn.style.background = '#5CE1E6';
    btn.innerText = `⌛ ${_runtime.i18n.getMessage('recording') || 'RECORDING...'}`;

    const peopleBtn = document.querySelector(G.selectors.peopleBtn);
    if (peopleBtn && peopleBtn.getAttribute('aria-pressed') !== 'true') {
      peopleBtn.click();
    }

    await new Promise(r => setTimeout(r, 1000));
    scrape();
    
    btn.style.background = '#34a853';
    btn.innerText = `✅ ${_runtime.i18n.getMessage('recorded') || 'Recorded!'}`;
    
    // Open Dashboard in new tab
    setTimeout(() => {
      _runtime.runtime.sendMessage({ type: 'OPEN_DASHBOARD' });
      btn.style.background = '#1a73e8';
      btn.innerHTML = `<span>📊</span> ${recordText}`;
    }, 1000);
  };

  wrap.appendChild(btn);
  document.body.appendChild(wrap);
}

// Start
setTimeout(() => { createUI(); scrape(); }, 3000);

// Safety backup scan every 5 seconds
setInterval(scrape, 5000);

// Use a debounced mutation observer for efficiency
let debounceTimer;
const obs = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(scrape, 1000);
});

obs.observe(document.body, { childList: true, subtree: true });
